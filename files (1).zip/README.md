# 🎮 Carréal - Jeu de Stratégie Abstrait

## 📝 Description

**Carréal** est un jeu de stratégie abstrait minimaliste où vous devez former des carrés sur une grille pour marquer des points. Simple à apprendre, difficile à maîtriser !

---

## 🎯 Concept du Jeu

### Principe de Base
Deux ou trois joueurs placent alternativement des points colorés sur une grille. Dès que **4 points d'un même joueur forment les coins d'un carré** (de n'importe quelle taille), ce joueur marque **1 point**.

### Objectif
🏆 Former le **maximum de carrés** avant que la grille soit remplie !

---

## 🕹️ Comment Jouer

### Règles Simples

1. **Tour par tour** : Les joueurs placent un point chacun leur tour
2. **Formation de carrés** : Quand vos 4 points forment un carré, vous marquez 1 point
3. **🔥 Règle Bonus** : Si vous formez un carré, **vous rejouez** !
4. **Toutes tailles** : Les carrés peuvent être de **n'importe quelle taille** (2×2, 3×3, 4×4, 5×5, etc.)
5. **Fin de partie** : Quand la grille est pleine, le joueur avec le plus de points gagne

### Exemple de Carrés Valides

```
⭕ - - - ⭕     Carré 4×4 = 1 point
|       |     
|       |     
⭕ - - - ⭕

⭕ - ⭕          Carré 2×2 = 1 point
|   |
⭕ - ⭕

⭕ - - - - - ⭕  Carré 6×6 = 1 point
|           |
|           |
|           |
|           |
|           |
⭕ - - - - - ⭕
```

**Important** : Seuls les **4 coins** doivent être de votre couleur, pas les côtés !

---

## ✨ Modes de Jeu

### 👥 Joueur vs Joueur (PvP)
- **2 joueurs** : Duel classique
- **3 joueurs** : Encore plus stratégique !
- Mode local sur le même appareil

### 🤖 Joueur vs IA
- **😊 Facile** : L'IA joue aléatoirement - idéal pour apprendre
- **😐 Moyen** : L'IA combine stratégie (50%) et hasard - bon challenge
- **😈 Difficile** : L'IA anticipe et joue stratégiquement - pour les experts !

---

## 🎨 Personnalisation

### Tailles de Grille
- **8×8** : Parties rapides (5-10 min)
- **10×10** : Standard (10-15 min) ⭐
- **12×12** : Stratégie approfondie (15-20 min)
- **14×14** : Pour les experts ! (20-30 min)

### Couleurs des Joueurs
- **⭕ Joueur 1** : Cyan électrique (`#64ffda`)
- **❌ Joueur 2** : Rose vif (`#ff6b9d`)
- **🔶 Joueur 3** : Jaune doré (`#ffd93d`)
- **🤖 IA** : Violet mystique (`#9d50ff`)

---

## 🧠 Stratégies Gagnantes

### 🎯 Tactiques Offensives
1. **Créer des opportunités multiples** : Placez des points qui peuvent former plusieurs carrés
2. **Viser les grands carrés** : Ils offrent plus d'opportunités de combo
3. **Enchaînements** : Profitez du coup bonus pour jouer plusieurs fois de suite

### 🛡️ Tactiques Défensives
1. **Bloquer l'adversaire** : Empêchez-le de compléter ses carrés
2. **Surveiller les coins** : Les coins de grands carrés sont cruciaux
3. **Contrôler le centre** : Plus d'opportunités de carrés

### 📍 Positionnement
- Le **centre** offre le plus d'opportunités
- Les **coins** de la grille sont moins intéressants
- Créez des **zones de contrôle** progressivement

---

## 💡 Astuces de Pro

### Pour les débutants 😊
- Commencez par former des **petits carrés 2×2**
- Placez vos points **proches les uns des autres**
- Ne négligez pas la **défense**

### Pour les intermédiaires 😐
- Apprenez à **anticiper** les coups adverses
- Créez des **configurations à double menace**
- Utilisez le **coup bonus** stratégiquement

### Pour les experts 😈
- Pensez en **termes de zones**
- Anticipez **2-3 coups à l'avance**
- Créez des **cascades de carrés**
- Maîtrisez l'art du **sacrifice tactique**

---

## 📱 Installation

### Jouer directement
1. Téléchargez et décompressez le ZIP
2. Ouvrez `index.html` dans votre navigateur
3. Le jeu démarre automatiquement !

### Installer comme application (PWA)

**Sur ordinateur :**
- Chrome/Edge : Cliquez sur l'icône "Installer" dans la barre d'adresse

**Sur mobile Android :**
- Chrome : Menu → "Ajouter à l'écran d'accueil"

**Sur iPhone/iPad :**
- Safari : Partager → "Sur l'écran d'accueil"

---

## 🤖 Intelligence Artificielle

### Comment l'IA joue

**Niveau 1 - Facile 😊**
- Joue complètement au hasard
- Parfait pour découvrir le jeu

**Niveau 2 - Moyen 😐**
- 50% stratégie + 50% hasard
- Crée un défi équilibré

**Niveau 3 - Difficile 😈**
L'IA utilise ces stratégies :
1. Cherche à former des carrés
2. Bloque les carrés de l'adversaire
3. Privilégie le centre et les zones stratégiques
4. Évalue les meilleurs coups possibles

---

## 📊 Statistiques

### Temps de jeu moyens
- **8×8** : 5-10 minutes
- **10×10** : 10-15 minutes
- **12×12** : 15-20 minutes
- **14×14** : 20-30 minutes

### Records théoriques
**Nombre maximum de carrés possibles :**

Pour une grille n×n, le nombre total de carrés de toutes tailles est :
```
Σ(k=1 to n-1) (n-k)²
```

- **8×8** : 140 carrés maximum
- **10×10** : 285 carrés maximum
- **12×12** : 506 carrés maximum
- **14×14** : 819 carrés maximum

---

## 🎓 Règles Avancées

### Comptage des Carrés
- Chaque carré ne compte qu'**une seule fois**
- Un seul coup peut former **plusieurs carrés** de tailles différentes
- Exemple : Placer un point peut compléter un carré 2×2 ET un carré 4×4 simultanément = **2 points** !

### Situations Spéciales
- **Égalité** : En cas de score identique, match nul
- **Grille pleine** : La partie se termine même s'il reste des carrés potentiels
- **3 joueurs** : Le jeu devient beaucoup plus imprévisible et tactique

---

## ⚙️ Configuration Technique

### Prérequis
- Navigateur moderne (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)
- JavaScript activé
- Aucune connexion Internet requise après installation

### Fichiers
```
carrreal/
├── index.html          # Page de chargement
├── carrreal.html       # Jeu complet
├── manifest.json       # Configuration PWA
├── sw.js              # Service Worker
└── README.md          # Ce fichier
```

---

## 🎯 Exemples de Parties

### Partie rapide (8×8)
- Durée : ~7 minutes
- Total de coups : 64
- Score moyen : 8-12 carrés par joueur

### Partie standard (10×10)
- Durée : ~12 minutes
- Total de coups : 100
- Score moyen : 15-25 carrés par joueur

### Partie expert (14×14)
- Durée : ~25 minutes
- Total de coups : 196
- Score moyen : 35-50 carrés par joueur

---

## 🏆 Défis

### Défis Solo
1. **Premier sang** : Former un carré au premier coup
2. **Combo master** : Jouer 5 fois de suite
3. **Géant** : Former un carré 7×7 ou plus
4. **Perfectionniste** : Gagner avec 2× le score de l'adversaire

### Défis vs IA
1. **David vs Goliath** : Battre l'IA difficile
2. **Sans faute** : Gagner sans laisser l'IA marquer
3. **Marathon** : Finir une partie 14×14 vs IA difficile

---

## 🐛 Résolution de Problèmes

**Le jeu ne démarre pas ?**
- Vérifiez que JavaScript est activé
- Essayez un autre navigateur
- Effacez le cache du navigateur

**L'IA ne répond pas ?**
- Rafraîchissez la page (F5)
- Vérifiez la console (F12)

**Problèmes d'affichage ?**
- Utilisez le zoom du navigateur (Ctrl + / Ctrl -)
- Sur mobile, passez en mode paysage
- Pour les grandes grilles, utilisez un écran plus grand

---

## 📜 Crédits

**Carréal** - Jeu de stratégie abstrait  
Version 1.0 - Janvier 2025

Inspiré des jeux de stratégie abstraits classiques avec une touche moderne.

---

## 🎉 Amusez-vous bien !

Que le meilleur stratège gagne ! 🏆

**Conseil final** : La clé de Carréal est l'équilibre entre **offense** (former vos carrés) et **défense** (bloquer l'adversaire). Bonne chance ! ✨

---

## ⚡ Démarrage Rapide

1. ✅ Ouvrez `index.html`
2. ✅ Choisissez votre mode (2 joueurs / 3 joueurs / vs IA)
3. ✅ Sélectionnez la taille (8×8 recommandé pour débuter)
4. ✅ Cliquez sur "Commencer"
5. ✅ Formez des carrés et gagnez ! 🎮
